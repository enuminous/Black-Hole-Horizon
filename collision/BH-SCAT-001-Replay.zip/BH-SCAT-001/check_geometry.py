"""Extra vacuum check on the smaller-distortion background, independent of the scalar equations."""
from pathlib import Path
import json
import numpy as np
from scipy.integrate import solve_ivp
from scatter import Exterior
path=Path(__file__).resolve().parent/'results'
rows=[]
for tag,dx in [('coarse',.2),('medium',.1),('fine',.05)]:
    grid=Exterior(dx,[-28,76],.03)
    n=len(grid.x)
    def deriv(t,y):
        q,v=y.reshape((2,n))
        out=np.stack([v,grid.d2(q)-grid.vz*q])
        out[:,:5]=0;out[:,-5:]=0
        return out.ravel()
    times=[8.,14.,22.]
    sol=solve_ivp(deriv,(0.,max(times)),np.r_[grid.initial_psi,np.zeros(n)],method='DOP853',
                  t_eval=times,rtol=2e-11,atol=1e-14,max_step=.12)
    assert sol.success
    s=np.genfromtxt(path/('small-'+tag+'.csv'),delimiter=',',names=True)
    residual=[];terms=[];time_error=[]
    for t,col in zip(times,sol.y.T):
        q,v=col.reshape((2,n))
        k,h,shift,kt,ht,shift_t=grid.geometry(q,v,grid.d2(q)-grid.vz*q)
        interior=(grid.x>=-5)&(grid.x<=28)
        hx, kx = grid.d1(h),grid.d1(k)
        hterm=2*h/grid.r**2
        # Vacuum even-parity mixed Einstein equation in Regge-Wheeler gauge.
        residual.extend((-shift_t+hx+hterm-kx)[interior])
        for component in (shift_t,hx,hterm,kx):terms.extend(component[interior])
        time_error.append(float(q[np.argmin(abs(grid.x-20))]-s['psi_g_x20'][np.argmin(abs(s['t']-t))]))
    rows.append(dict(dx=dx,relative_mixed_constraint_L2=float(np.linalg.norm(residual)/np.linalg.norm(terms)),
        max_abs_Zerilli_time_integrator_difference_x20=max(abs(v) for v in time_error)))
(path/'metric-check.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
