#!/bin/sh
set -eu
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
sha256sum -c protocol.sha256 diagnostic.sha256
for prefix in '' small-; do
    if [ -z "$prefix" ]; then a=.06; else a=.03; fi
    python scatter.py "${prefix}coarse" --dx .2 --half-separation "$a"
    python scatter.py "${prefix}medium" --dx .1 --half-separation "$a"
    python scatter.py "${prefix}fine" --dx .05 --half-separation "$a"
    python scatter.py "${prefix}wide" --dx .1 --domain -32 84 --half-separation "$a"
    python scatter.py "${prefix}spherical" --dx .1 --half-separation 0
    python scatter.py "${prefix}wrong" --dx .05 --wrong-mass --half-separation "$a"
    python analyze.py --prefix="$prefix"
done
python scatter.py extra --dx .025
python diagnose.py
python check_geometry.py
