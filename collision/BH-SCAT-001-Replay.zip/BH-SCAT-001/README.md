# BH-SCAT-001 · Scalar scattering in a black-hole collision exterior

**Result.** On a time-dependent, equal-mass head-on merger exterior, an initially absent linear C1 scalar remained zero. A positive and a negative spherical seed produced sign-reversed monopole and quadrupole waveforms. A conventional Klein–Gordon field with the effective mass reproduced both. The original geometry exceeded the predeclared perturbation-size screen. A separately recorded, smaller-distortion repeat passed every screen. This is a comparison of two numerical implementations of a shared continuum equation.

![Smaller-distortion run, with the signed C1 pulses and matched comparator](results/small-waveforms.png)

## Measurement

The recorded quantity is the signed scalar waveform at a finite coordinate radius in Regge–Wheeler gauge. The main observer is at tortoise coordinate x=20M, and another is at x=18M. Each CSV has one column per radius, code, scalar Legendre coefficient (0 or 2), and seed. The gravitational Zerilli function is also recorded. The pulse is initially time symmetric, so it splits into ingoing and outgoing components. These scalar traces describe the exterior wave field. Detector strain, flux at infinity, complete inspiral, formation of the common horizon, and nonlinear feedback were outside the calculation.

| Main comparison at dx=0.05M | Original half separation 0.06M | Diagnostic half separation 0.03M |
|---|---:|---:|
| Maximum sampled absolute metric coefficient in extraction cone, screen <0.10 | 0.15142 · fail | 0.03785 · pass |
| Maximum absolute zero-arm state, every step and point, both codes | 0 | 0 |
| C1 positive plus negative waveform, peak absolute sum, both multipoles | 0 | 0 |
| C1 versus matched scalar, relative waveform L2 error (monopole) | 0.01943% | 0.01943% |
| C1 versus matched scalar, relative waveform L2 error (quadrupole) | 0.03841% | 0.03841% |
| Peak absolute positive C1 monopole, r phi_0 | 4.06146e−5 | 4.06146e−5 |
| Peak absolute positive C1 quadrupole, r phi_2 | 3.89078e−9 | 9.72696e−10 |
| Unmatched bare-mass comparator vs C1, monopole L2 error | 84.13% | 84.13% |

The scalar quadrupole disappeared exactly in the spherical-background control. The fourth-grid diagnostic for the original geometry reduced the matched discrepancies to 0.00486% (monopole) and 0.00960% (quadrupole), while the metric maximum remained 0.15142. This distinguishes a model-range issue from scalar grid error. Halving the separation quartered the quadrupole and left the monopole unchanged, as imposed by the leading-order geometry. The reduction establishes internally consistent scaling. The 0.10 screen is an analyst-selected coordinate diagnostic. Passing it supplies no bound on omitted nonlinear terms.

## Physics and calculation

Use geometric units with total ADM mass M=1, scalar mass mM=0.20, g/M_Pl=0.5, and no gauge or matter fields. To linear order about the zero-field Ricci-flat solution, elimination of the perturbed Ricci scalar gives Z □phi − m² phi = 0, with Z=1+6g²/M_Pl²=2.5. The conventional field has mass mu M=0.1264911064. Values are illustrative. Both codes evolve the same field normalization with initial r phi_0 equal to 0 or ±1e−4 times exp[−(x−8)²/8], with initial scalar velocities zero. There is no fitted mass or coupling. The comparator's different spatial discretization and variables test numerical implementation. The two theories coincide at this order by construction.

Equal masses at isotropic z=±a give the time-symmetric Brill–Lindquist conformal factor. At order a² the spatial perturbation has H2=K=2a²/[rho³(1+1/(2rho))] as the coefficient of the Legendre polynomial P2. Transform using r=rho(1+1/(2rho))² and x=r+2 ln(r/2−1). Initialize the even-parity Zerilli–Moncrief function from H2 and K with vanishing initial time derivative, evolve the vacuum quadrupole wave equation and reconstruct K, H=H0=H2 and H1. This is a genuine time-dependent binary close-limit exterior. The two punctures start within the assumed common horizon. No numerical relativity inspiral or observed event waveform is substituted for a volume metric. The metric is correct to first order in the binary distortion. Scalar evolution keeps its product with the scalar amplitude so the spherical seed can excite a quadrupole.

For auditability, in (t,x) coordinates the perturbed metric has g_tt=−f(1−H P2), g_tx=f H1 P2, g_xx=f(1+H P2), and angular block r²(1+K P2) times the unit-sphere metric, where f=1−2/r. C1 evolves phi and its weighted canonical momentum in radial divergence form using face fluxes. The comparator independently evolves u=r phi using a fourth-order spatial stencil, the potential f[l(l+1)/r²+2/r³+mu²], and the expanded first-order metric source for l=2. They share the metric, mesh, RK4 time integrator and initial conditions. Both signs and the zero state have separate evolved arrays. The code retains leading monopole-to-quadrupole conversion only. It cannot settle stability against arbitrary perturbations or growing modes over longer times.

The original three grids had dx=0.20, 0.10 and 0.05M with dt=dx/4 and t_end=36M. C1 self-convergence orders were 2.004 and 2.007 in the two multipoles. The comparator orders were 3.995 and 3.996. The widened domain changed either extracted waveform by less than 4e−12 relative L2 at the intermediate resolution. A separate DOP853 integration of the background and a mixed vacuum Einstein-equation residual check are in results/metric-check.json. The residual decreased from 1.24e−4 on the coarse grid to 3.49e−8 on the fine grid on the sampled subdomain. These checks cannot validate the omitted strong-field nonlinearities. The zero and sign relations follow from homogeneity and linearity. A distinct EFMW physical prediction still requires a source, initial condition, or additional observable supplied independently of this calculation.

## Replay and files

Use Python 3.12.14. From the extracted directory:

```sh
sha256sum -c SHA256SUMS
python -m pip install -r requirements.txt
sh replay.sh
```

The checksums describe the archived files before rerunning. Elapsed times and image encodings can change. Compare the numerical waveform columns and the verdict JSONs. The primary protocol and the later diagnostic each have a local SHA-256 record. The diagnostic followed inspection of the primary result. The primary verdict remains in results/verdict.json, and the separate repeat is in results/small-verdict.json. The complete four-grid comparison is in results/diagnostic-results.json. CSV and JSON pairs labeled wrong are the deliberately mismatched mass cases. Spherical and wide pairs are the geometry controls. The background check is retrospective.

## Sources

- [Pinned EFMW C1 action](https://github.com/enuminous/EFMW-Lagrangian/blob/83f9d2ec03e055c6cd09aa6359189161ad1571f6/candidate/CANDIDATE.md) and [prior horizon study](https://github.com/enuminous/Black-Hole-Horizon/blob/be4c183a76aab7ffdcf9b22a7f9a8d9c662e8d36/EFMW_MAPPING.md).
- Head-on close limit and the common-horizon assumption. [Price and Pullin](https://arxiv.org/abs/gr-qc/9402039).
- Brill–Lindquist close-limit evolution. [Yoshino, Shiromizu and Shibata](https://arxiv.org/abs/gr-qc/0508063).
- Even-parity vacuum perturbation formalism. [Martel and Poisson](https://doi.org/10.1103/PhysRevD.71.104003). [Explicit metric reconstruction](https://blackhole.org/black-hole-perturbations/even-parity-metric-perturbations/).
- Prior numerical scalar–tensor binary work. [Healy et al.](https://arxiv.org/abs/1112.3928).
