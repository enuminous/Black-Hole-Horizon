"""Measure the extra refinement and test the smaller-distortion scaling prediction."""
from pathlib import Path
import json
import numpy as np
p=Path(__file__).resolve().parent/'results'
def data(tag):
    return np.genfromtxt(p/(tag+'.csv'),names=True,delimiter=',')
d={tag:data(tag) for tag in ('medium','fine','extra','small-fine')}
result={}
for code in ('C1','KG'):
    for ell in (0,2):
        key=f'{code}_l{ell}_plus_x20'
        med,fine,extra,sm=(d[t][key] for t in d)
        ratio=np.linalg.norm(sm)/np.linalg.norm(fine)
        pred=1. if ell==0 else .25
        error=float(np.linalg.norm(sm-pred*fine)/np.linalg.norm(pred*fine))
        assert error < 1e-8
        result[key]=dict(small_to_original_norm_ratio=ratio,scaling_waveform_relative_error=error,
            extra_refinement_order=float(np.log2(np.linalg.norm(med-fine)/np.linalg.norm(fine-extra))),
            extra_C1_vs_matched_relative_error=float(np.linalg.norm(d['extra'][f'C1_l{ell}_plus_x20']-d['extra'][f'KG_l{ell}_plus_x20'])/np.linalg.norm(d['extra'][f'KG_l{ell}_plus_x20'])))
(p/'diagnostic-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
